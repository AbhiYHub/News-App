package com.appdid.otpverification;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import me.fahmisdk6.avatarview.AvatarView;

public class Settings extends AppCompatActivity {

    private TextView mName,mAge,mCity,mGender,mLogOut,mEditProfile;

    AvatarView mProfileInit;

    private String initial,userId;

    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sp = getSharedPreferences("data", Context.MODE_PRIVATE);
        mName = findViewById(R.id.profile_name);
        mAge = findViewById(R.id.age);
        mCity = findViewById(R.id.city);
        mGender = findViewById(R.id.gender);
        mLogOut = findViewById(R.id.logout);
        mEditProfile = findViewById(R.id.edit_profile);
        mProfileInit = findViewById(R.id.avatar);

        mAuth = FirebaseAuth.getInstance();
        userId = mAuth.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference();


        mProfileInit.bind(sp.getString("Name","No Name"),null);





        mLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(Settings.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                SharedPreferences.Editor editor = sp.edit();
                editor.clear();
                editor.commit();
                startActivity(intent);
            }
        });

        mEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent edit = new Intent(Settings.this, EditActivity.class);
                startActivity(edit);
            }
        });


        putData();

    }

    protected boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }

    private void putData(){

        databaseReference.child("Users").child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mName.setText(dataSnapshot.child("Name").getValue().toString());
                mAge.setText(dataSnapshot.child("Age").getValue().toString());
                mCity.setText(dataSnapshot.child("City").getValue().toString());
                mGender.setText(dataSnapshot.child("Gender").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


}



