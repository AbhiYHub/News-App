package com.appdid.otpverification;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Pojo{

    public String pojoValue;

    private Context context;

    public Pojo(Context context){
        this.context = context;
    }

    public Pojo() {

    }

    public String getPojo(final String key, boolean SAVED_ONLINE) {

        if(SAVED_ONLINE){
            FirebaseAuth mSaveAuth;
            mSaveAuth = FirebaseAuth.getInstance();
            FirebaseUser user = mSaveAuth.getCurrentUser();
            final String userId = user.getUid();
            DatabaseReference reference;
            reference = FirebaseDatabase.getInstance().getReference();
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    for(DataSnapshot ds: dataSnapshot.getChildren()) {
                        DataStorage dataStorage = new DataStorage();
                        if(key.equals("Name")) {
                            dataStorage.setdName(ds.child(userId).getValue(DataStorage.class).getdName());
                            pojoValue = dataStorage.getdName();
                        }else if(key.equals("Email")) {
                            dataStorage.setdEmail(ds.child(userId).getValue(DataStorage.class).getdEmail());
                            pojoValue = dataStorage.getdName();
                        }else if (key.equals("Age")) {
                            dataStorage.setdAge(ds.child(userId).getValue(DataStorage.class).getdAge());
                            pojoValue = dataStorage.getdName();
                        }else if (key.equals("Gender")) {
                            dataStorage.setdGender(ds.child(userId).getValue(DataStorage.class).getdGender());
                            pojoValue = dataStorage.getdName();
                        }else if (key.equals("Phone")) {
                            dataStorage.setdPhone(ds.child(userId).getValue(DataStorage.class).getdPhone());
                            pojoValue = dataStorage.getdName();
                        }else if (key.equals("City")) {
                            dataStorage.setdCity(ds.child(userId).getValue(DataStorage.class).getdCity());
                            pojoValue = dataStorage.getdName();
                        }


                        //pojoName = dataSnapshot.child(key).getValue().toString();

                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {



                }
            });
            SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
            pojoValue = sp.getString(key, "Not Entered");
            return pojoValue;
        }else {
            SharedPreferences sp = context.getSharedPreferences("data", Context.MODE_PRIVATE);
            pojoValue = sp.getString(key, "Not Entered");
            return pojoValue;
        }
    }

    void setPojo(String key,String pojoName,boolean LoggedIn) {

        if(LoggedIn) {
            FirebaseAuth mSaveAuth;
            mSaveAuth = FirebaseAuth.getInstance();
            FirebaseUser user = mSaveAuth.getCurrentUser();
            String userId = user.getUid();
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Users");
            myRef.child(userId).child(key).setValue(pojoName);
        }

        SharedPreferences sharedPreferences = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key,pojoName);
        editor.apply();
    }
}
