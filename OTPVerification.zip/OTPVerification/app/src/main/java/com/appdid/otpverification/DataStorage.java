package com.appdid.otpverification;

public class DataStorage {

    String dName,dPhone,dEmail,dGender,dAge,dCity;

    public DataStorage(String dName, String dPhone, String dEmail, String dGender, String dAge, String dCity) {
        this.dName = dName;
        this.dPhone = dPhone;
        this.dEmail = dEmail;
        this.dGender = dGender;
        this.dAge = dAge;
        this.dCity = dCity;
    }

    public DataStorage() {

    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getdPhone() {
        return dPhone;
    }

    public void setdPhone(String dPhone) {
        this.dPhone = dPhone;
    }

    public String getdEmail() {
        return dEmail;
    }

    public void setdEmail(String dEmail) {
        this.dEmail = dEmail;
    }

    public String getdGender() {
        return dGender;
    }

    public void setdGender(String dGender) {
        this.dGender = dGender;
    }

    public String getdAge() {
        return dAge;
    }

    public void setdAge(String dAge) {
        this.dAge = dAge;
    }

    public String getdCity() {
        return dCity;
    }

    public void setdCity(String dCity) {
        this.dCity = dCity;
    }
}
