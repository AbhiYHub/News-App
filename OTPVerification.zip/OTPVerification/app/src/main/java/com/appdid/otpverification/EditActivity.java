package com.appdid.otpverification;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditActivity extends AppCompatActivity {

    EditText mProfileName,mGender,mAge,mCity;
    Button button;
    Pojo pojo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        mProfileName = findViewById(R.id.profile_name);
        mAge = findViewById(R.id.age);
        mCity = findViewById(R.id.city);
        mGender = findViewById(R.id.gender);
        button = findViewById(R.id.save);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mProfileName.getText().toString().length() !=0)
                {
                    updateItemInDataBase("Name",mProfileName.getText().toString().trim());
                }
                if(mAge.getText().toString().length() !=0)
                {
                    updateItemInDataBase("Age",mAge.getText().toString().trim());
                }
                if(mCity.getText().toString().length() !=0)
                {
                    updateItemInDataBase("City",mCity.getText().toString().trim());
                }
                if(mGender.getText().toString().length() !=0)
                {
                    updateItemInDataBase("Gender",mGender.getText().toString().trim());
                }

            }
        });

    }

    void updateItemInDataBase(String itemName,String itemValue)
    {

        pojo = new Pojo(EditActivity.this);
        pojo.setPojo(itemName,itemValue,true);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setTitle("Updated Successfully");
        builder.setMessage("Your Data has been updated Successfully");
        builder.show();

    }
}
